// Configuración del afinador
const tunerConfig = {
    targetFrequency: 220, // Frecuencia exacta para A (LA)
    minFrequency: 210,
    maxFrequency: 230,
    tolerance: 0.5, // Tolerancia en Hz para considerar afinado
    warningRange: 3, // Rango de advertencia en Hz
    majorTicks: 10
};

// Elementos del DOM
const canvas = document.getElementById('tunerMeter');
const ctx = canvas.getContext('2d');
const frequencyDisplay = document.getElementById('frequencyDisplay');
const tuningStatus = document.getElementById('tuningStatus');
const currentFreqSpan = document.getElementById('currentFreq');
const deviationSpan = document.getElementById('deviation');
const accuracySpan = document.getElementById('accuracy');
const needlePosition = document.getElementById('needlePosition');
const jsonInput = document.getElementById('jsonInput');

// Variable para la frecuencia actual
let currentFrequency = tunerConfig.targetFrequency;

// Datos de ejemplo para el JSON
const sampleJSONData = {
    "guitar_tuner": {
        "frequency": 240.5,
        "note": "A",
        "octave": 3,
        "accuracy": 0.95,
        "string": "A3"
    }
};

// Función para dibujar el medidor
function drawTunerMeter(frequency) {
    ctx.clearRect(0, 0, 400, 400);
    
    const centerX = 200;
    const centerY = 200;
    const radius = 160;
    const startAngle = Math.PI * 0.75; // 135 grados
    const endAngle = Math.PI * 2.25; // 405 grados
    
    // Dibujar el arco de fondo
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, endAngle);
    ctx.lineWidth = 25;
    ctx.strokeStyle = '#e2e8f0';
    ctx.stroke();
    
    // Calcular el ángulo para la frecuencia actual
    const frequencyRange = tunerConfig.maxFrequency - tunerConfig.minFrequency;
    const normalizedFreq = (frequency - tunerConfig.minFrequency) / frequencyRange;
    const freqAngle = startAngle + normalizedFreq * (endAngle - startAngle);
    
    // Dibujar el arco de frecuencia
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, freqAngle);
    ctx.lineWidth = 25;
    
    // Crear gradiente basado en la precisión
    const deviation = Math.abs(frequency - tunerConfig.targetFrequency);
    let gradientColor;
    
    if (deviation <= tunerConfig.tolerance) {
        gradientColor = '#48bb78'; // Verde - afinado
    } else if (deviation <= tunerConfig.warningRange) {
        gradientColor = '#f6ad55'; // Naranja - cerca
    } else {
        gradientColor = '#f56565'; // Rojo - desafinado
    }
    
    ctx.strokeStyle = gradientColor;
    ctx.stroke();
    
    // Dibujar marcas de frecuencia
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#718096';
    ctx.fillStyle = '#4a5568';
    ctx.font = 'bold 10px Arial';
    ctx.textAlign = 'center';
    
    for (let i = 0; i <= tunerConfig.majorTicks; i++) {
        const tickFreq = tunerConfig.minFrequency + (i * (frequencyRange / tunerConfig.majorTicks));
        const tickAngle = startAngle + (i / tunerConfig.majorTicks) * (endAngle - startAngle);
        
        // Marca principal
        ctx.beginPath();
        ctx.moveTo(
            centerX + (radius - 15) * Math.cos(tickAngle),
            centerY + (radius - 15) * Math.sin(tickAngle)
        );
        ctx.lineTo(
            centerX + (radius - 30) * Math.cos(tickAngle),
            centerY + (radius - 30) * Math.sin(tickAngle)
        );
        ctx.stroke();
        
        // Valor de frecuencia
        ctx.fillStyle = '#4a5568';
        ctx.fillText(
            Math.round(tickFreq),
            centerX + (radius - 45) * Math.cos(tickAngle),
            centerY + (radius - 45) * Math.sin(tickAngle)
        );
    }
    
    // Marca especial para 220 Hz (target)
    const targetAngle = startAngle + ((tunerConfig.targetFrequency - tunerConfig.minFrequency) / frequencyRange) * (endAngle - startAngle);
    
    ctx.beginPath();
    ctx.moveTo(
        centerX + (radius - 15) * Math.cos(targetAngle),
        centerY + (radius - 15) * Math.sin(targetAngle)
    );
    ctx.lineTo(
        centerX + (radius - 40) * Math.cos(targetAngle),
        centerY + (radius - 40) * Math.sin(targetAngle)
    );
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#667eea';
    ctx.stroke();
    
    // Dibujar la aguja
    const needleX = centerX + 120 * Math.cos(freqAngle);
    const needleY = centerY + 120 * Math.sin(freqAngle);
    
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(needleX, needleY);
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#2d3748';
    ctx.stroke();
    
    // Círculo central
    ctx.beginPath();
    ctx.arc(centerX, centerY, 15, 0, Math.PI * 2);
    ctx.fillStyle = gradientColor;
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Actualizar posición del indicador
    updateNeedlePosition(frequency);
    
    // Actualizar estado de afinación
    updateTuningStatus(frequency);
}

// Función para actualizar la posición de la aguja indicadora
function updateNeedlePosition(frequency) {
    const range = tunerConfig.maxFrequency - tunerConfig.minFrequency;
    const position = ((frequency - tunerConfig.minFrequency) / range) * 100;
    needlePosition.style.left = `${position}%`;
}

// Función para actualizar el estado de afinación
function updateTuningStatus(frequency) {
    const deviation = frequency - tunerConfig.targetFrequency;
    const absDeviation = Math.abs(deviation);
    
    if (absDeviation <= tunerConfig.tolerance) {
        tuningStatus.textContent = '✓ AFINADO';
        tuningStatus.style.background = '#48bb78';
    } else if (absDeviation <= tunerConfig.warningRange) {
        if (deviation < 0) {
            tuningStatus.textContent = '↓ BAJO (b)';
        } else {
            tuningStatus.textContent = '↑ ALTO (#)';
        }
        tuningStatus.style.background = '#f6ad55';
    } else {
        if (deviation < 0) {
            tuningStatus.textContent = '↓↓ MUY BAJO';
        } else {
            tuningStatus.textContent = '↑↑ MUY ALTO';
        }
        tuningStatus.style.background = '#f56565';
    }
}

// Función para actualizar toda la interfaz
function updateFrequency(frequency) {
    // Asegurar que la frecuencia está dentro del rango
    currentFrequency = Math.min(
        Math.max(frequency, tunerConfig.minFrequency),
        tunerConfig.maxFrequency
    );
    
    // Actualizar el medidor
    drawTunerMeter(currentFrequency);
    
    // Actualizar displays
    frequencyDisplay.textContent = currentFrequency.toFixed(1);
    currentFreqSpan.textContent = `${currentFrequency.toFixed(1)} Hz`;
    
    // Calcular desviación
    const deviation = currentFrequency - tunerConfig.targetFrequency;
    const deviationText = deviation > 0 ? `+${deviation.toFixed(2)}` : deviation.toFixed(2);
    deviationSpan.textContent = `${deviationText} Hz`;
    
    // Calcular precisión (porcentaje)
    const maxDeviation = Math.max(
        tunerConfig.maxFrequency - tunerConfig.targetFrequency,
        tunerConfig.targetFrequency - tunerConfig.minFrequency
    );
    const accuracy = 100 - (Math.abs(deviation) / maxDeviation * 100);
    accuracySpan.textContent = `${Math.max(0, accuracy.toFixed(1))}%`;

    // Cambiar color del display según la precisión
    if (Math.abs(deviation) <= tunerConfig.tolerance) {
        frequencyDisplay.style.color = '#48bb78';
    } else if (Math.abs(deviation) <= tunerConfig.warningRange) {
        frequencyDisplay.style.color = '#f6ad55';
    } else {
        frequencyDisplay.style.color = '#f56565';
    }
}

// Función para procesar datos JSON
function processFrequencyData(data) {
    try {
        let frequency = null;
        
        // Soporte para diferentes estructuras de JSON
        if (data.guitar_tuner && data.guitar_tuner.frequency) {
            frequency = data.guitar_tuner.frequency;
        } else if (data.frequency) {
            frequency = data.frequency;
        } else if (data.value) {
            frequency = data.value;
        }
        
        if (frequency !== null) {
            updateFrequency(frequency);
        } else {
            alert('Error: No se encontró una frecuencia válida en el JSON');
        }
    } catch (error) {
        console.error('Error procesando JSON:', error);
        alert('Error al procesar el JSON');
    }
}

// Función para procesar JSON personalizado
function processCustomJSON() {
    try {
        const jsonText = jsonInput.value;
        const data = JSON.parse(jsonText);
        processFrequencyData(data);
    } catch (error) {
        alert('Error: JSON inválido. Por favor verifica el formato.');
    }
}

// Función para generar frecuencia aleatoria
function generateRandomFrequency() {
    const min = tunerConfig.minFrequency;
    const max = tunerConfig.maxFrequency;
    const randomFreq = min + (Math.random() * (max - min));
    updateFrequency(randomFreq);
}

// Inicializar el medidor
updateFrequency(tunerConfig.targetFrequency);

// Ejemplo de diferentes formatos JSON soportados
console.log('Formatos JSON soportados:');
console.log('Formato 1:', {
    guitar_tuner: {
        frequency: 221.3,
        note: 'A'
    }
});
console.log('Formato 2:', {
    frequency: 219.7
});
console.log('Formato 3:', {
    value: 220.5,
    unit: 'Hz'
});